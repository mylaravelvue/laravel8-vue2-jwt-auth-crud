//const App = () => import('./components/App.vue' /* webpackChunkName: "resource/js/components/app" */)
const Welcome = () => import('./components/Welcome.vue' /* webpackChunkName: "resource/js/components/welcome" */)
const CategoryList = () => import('./components/category/List.vue' /* webpackChunkName: "resource/js/components/category/list" */)
const CategoryCreate = () => import('./components/category/Add.vue' /* webpackChunkName: "resource/js/components/category/add" */)
const CategoryEdit = () => import('./components/category/Edit.vue' /* webpackChunkName: "resource/js/components/category/edit" */)
const Register = () => import('./components/login/Register.vue' /* webpackChunkName: "resource/js/components/category/list" */)
const Login = () => import('./components/login/Login.vue' /* webpackChunkName: "resource/js/components/category/list" */)

export const routes = [
    {
        name: 'home',
        path: '/',
        component: Welcome
        //component: App
    },
    {
        name: 'categoryList',
        path: '/category',
        component: CategoryList
    },
    {
        name: 'categoryEdit',
        path: '/category/:id/edit',
        component: CategoryEdit
    },
    {
        name: 'categoryAdd',
        path: '/category/add',
        component: CategoryCreate
    },
    {
        name: 'registerUser',
        path: '/login/register',
        component: Register
    },
    {
        name: 'loginUser',
        path: '/login/login',
        component: Login
    }
]





