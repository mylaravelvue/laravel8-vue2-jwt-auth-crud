<template>
    <main>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <router-link to="/" class="navbar-brand" href="#"></router-link>
                <div class="collapse navbar-collapse">
                    <div class="navbar-nav">
                        <router-link exact-active-class="active" to="/" class="nav-item nav-link" >Home</router-link>
                        <router-link exact-active-class="active" to="/category" class="nav-item nav-link">Category</router-link>
                    </div>
                </div>
            </div>
        <ul class="navbar-nav">
        <li class="nav-item">
          <router-link exact-active-class="active" :to='{name:"loginUser"}' class="nav-item nav-link" >Login</router-link>
        </li>
      </ul>
       <ul class="navbar-nav ml-auto" >
        <li class="nav-item">
          <router-link exact-active-class="active" :to='{name:"registerUser"}' class="nav-item nav-link" >Register</router-link>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto" >
        <li class="nav-link" v-if="isLoggedIn"> Hi, {{name}}</li>
        <li class="nav-item">
          <router-link exact-active-class="active" to="/logout" class="nav-item nav-link" >Logout</router-link>
        </li>
      </ul>
        </nav>
        <div class="container mt-5">
            <router-view></router-view>
        </div>
    </main>
</template>

<script>
    export default {
        
        data(){
            return {
                isLoggedIn : null,
                name : null
            }
        },
        mounted(){
            this.isLoggedIn = localStorage.getItem('jwt')
            this.name = localStorage.getItem('user')
        }
    }
</script>